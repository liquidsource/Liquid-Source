<hgroup>
	<h1 class="site_title"><a href="index.php?module=ad_home">Website Admin</a></h1>
	<h2 class="section_title"><?php echo getMetaInfo($module,'title'); ?></h2><div class="btn_view_site"><a href="../index.php">View Site</a></div>
</hgroup>