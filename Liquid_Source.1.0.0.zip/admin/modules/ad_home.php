<article class="module width_full">
<header>
<h3 class="tabs_involved">Dashboard</h3>
</header>

<div class="module_content">
Welcome to your dashboard.
</div>

</article>