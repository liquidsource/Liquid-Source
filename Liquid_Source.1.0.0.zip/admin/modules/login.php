<article class="module width_full">
<header><h3 class="tabs_involved">Login</h3></header>
<div style="width: 400px; margin: 20px auto;" class="module_content">
<form method="post" action="scripts/action.php?action=login&to=ad_home">
<fieldset>
    <label style="width:150px">Username</label>
    <input type="text" name="m_username" id="m_username" style="width:370px" />
    <div class="clear" style="padding:1px;">&nbsp;</div>
    <label style="width:150px">Password</label>
    <input type="password" name="m_password" id="m_password" style="width:370px" />
    <div class="clear" style="padding:1px;">&nbsp;</div>
    <div class="submit_link">
        <input type="submit" value="Login" class="alt_btn">
    </div>
</fieldset>
</form>
</div>
</article>
<script type="text/javascript">$('#m_username').focus();</script>