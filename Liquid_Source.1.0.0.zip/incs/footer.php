<div class="wrap group">
    <div class="f_left">
        <ul class="group">
            <li class="noleftpad">Copyright &copy; <?php echo date("Y"); ?></li>
            <li><a href="<?php echo SITEMAP_LOCATION; ?>">Sitemap</a></li>
            <li><a href="<?php echo RSS_LOCATION; ?>">RSS</a></li>
            <li class="endlist"><a href="http://www.squashednewt.com">Built by SquashedNewt Ltd</a></li>
        </ul>
    </div>
    <div class="f_right">
        <ul class="group">
            <li><a href="<?php echo FACEBOOK_PAGE_URL; ?>"><img src="images/icons/facebook.png" alt="facebook" /></a></li>
            <li><a href="<?php echo TWITTER_PAGE_URL; ?>"><img src="images/icons/twitter.png" alt="twitter" /></a></li>
            <li><a href="<?php echo FACEBOOK_PAGE_ID; ?>"><img src="images/icons/linkedin.png" alt="linkedin" /></a></li>
            <li><a href="<?php echo GOOGLE_PLUS_PAGE_URL; ?>"><img src="images/icons/gplus.png" alt="google plus" /></a></li>
        </ul>
    </div>
</div>