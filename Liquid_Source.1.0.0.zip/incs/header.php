<div id="top_header">
	<div class="wrap group">
	    <a href="home"><img src="images/<?php echo LOGO_URL; ?>" alt="top logo" id="top_logo" class="f_left" /></a>
	</div>
</div>
<nav id="menu"><?php include("incs/menu.php"); ?></nav>