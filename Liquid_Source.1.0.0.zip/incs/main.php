<div class="wrap group">
    <?php echo getAlertMessage($_SESSION['_mtype'],$_SESSION['_msg']); ?>
    <?php getModuleData($module); ?>
</div>