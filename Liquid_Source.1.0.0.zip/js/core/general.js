/* These should be set as the same as the backend Site Option Modules */
var usingFormParser = true;
var usingTableParser = true;
var usingGoogleMaps = true;
var usingShadowbox = true;
var usingFlexSlider = true;
var usingContentSlider = true;

/* This function sets up the google maps. It is only called if Google Maps is turned on */
function initialize_gm() {
	var myOptions = {
		center: new google.maps.LatLng(-34.397, 150.644),
		zoom: 8,
		mapTypeId: google.maps.MapTypeId.ROADMAP
	};
	var map = new google.maps.Map(document.getElementById("map_canvas"),myOptions);
}

/*
 * Do not edit below this line
 */

$(document).ready(function() {
    $(".datepicker").datepicker({
        dateFormat: 'dd-mm-yy'
    });
    
    if(usingTableParser) {
	    // Uncommment out for multipage ajax sorting
	    $('.dataTable').dataTable({
			/*
			 "bProcessing": true,
	        "bServerSide": true,
	        "sAjaxSource": "scripts/locationofajax.php"
	        *
			*/
		});
	}
	
	if(usingGoogleMaps) {
		initialize_gm();
	}
	if(usingShadowbox) {
		Shadowbox.init();
	}
	if(usingContentSlider) {
		$('#slider1').bxSlider({
			speed: 500,
			auto: true,
			pager: true
		});
	}
	if(usingFlexSlider) {
		$('.flexslider').flexslider();
	}
});
function usingParser(parseType) {
	$.ajax({
	    type: "POST",
	    url: "scripts/ajaxcalls.php?ajaxcall=usingParser&parseType=" + parseType,
	    success: function(data) {
	    	if(data != 1) { return 0; }
	    	return 1;
	    }
	});
}