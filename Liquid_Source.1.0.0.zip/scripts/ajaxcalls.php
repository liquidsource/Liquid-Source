<?php
include("system.php");

switch (strtolower($_GET['ajaxcall'])) {
	case "usingparser":
		echo constant('USE_' . $_GET['parseType'] . '_PARSER');
		break;
	case "get2":
		break;
}
?>
